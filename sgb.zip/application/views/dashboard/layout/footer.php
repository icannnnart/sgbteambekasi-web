               <!-- content-wrapper ends -->
               <!-- partial:../../partials/_footer.html -->
               <footer class="footer">
                  <div class="d-sm-flex justify-content-center justify-content-sm-between">
                     <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © <?=date('Y')?>.  SGB TEAM BEKASI. All rights reserved.</span>
                     <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Powered By ICANART</span>
                  </div>
               </footer>
               <!-- partial -->
            </div>
            <!-- main-panel ends -->
         </div>
         <!-- page-body-wrapper ends -->
      </div>
      <!-- container-scroller -->
      <!-- plugins:js -->
      
      <!-- endinject -->
      <!-- Plugin js for this page -->
      <!-- End plugin js for this page -->
      <!-- inject:js -->
      <script src="<?=base_url('assets/dashboard/')?>js/off-canvas.js"></script>
      <script src="<?=base_url('assets/dashboard/')?>js/hoverable-collapse.js"></script>
      <script src="<?=base_url('assets/dashboard/')?>js/template.js"></script>
      <script src="<?=base_url('assets/dashboard/')?>js/settings.js"></script>
      <script src="<?=base_url('assets/dashboard/')?>js/todolist.js"></script>
      
      
      <script src="<?=base_url('assets/dashboard')?>/js/jquery.cookie.js" type="text/javascript"></script>
      <script src="<?=base_url('assets/dashboard')?>/vendors/datatables.net/jquery.dataTables.js"></script>
      <script src="<?=base_url('assets/dashboard')?>/vendors/datatables.net-bs5/dataTables.bootstrap5.js"></script>
      
      <!-- endinject -->
      <!-- Custom js for this page-->
      <!-- End custom js for this page-->
   </body>
</html>