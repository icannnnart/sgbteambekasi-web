<!DOCTYPE html>
<!-- coding by helpme_coder -->
<html>

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="<?=base_url('assets/login/')?>sgb.jpg" />
      <link rel="icon" href="<?=base_url('assets/login/')?>sgb.jpg" sizes="32x32" />
      <meta http-equiv="Content-Security-Policy" content="upgrade-insecure-requests">
      <link rel="icon" href="<?=base_url('assets/login/')?>sgb.jpg" sizes="192x192" />
      <link rel="apple-touch-icon" href="<?=base_url('assets/login/')?>sgb.jpg" />
      <meta name="msapplication-TileImage" content="<?=base_url('assets/login/')?>sgb.jpg" />
      <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <title>SGBTEAM BEKASI - <?=$title?></title>
    <link rel="stylesheet" href="<?=base_url('assets/login/')?>style.css" />
</head>